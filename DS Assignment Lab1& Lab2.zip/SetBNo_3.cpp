#include <iostream>
using namespace std;
void BubbleSort(int a[],int b)
{
  int temp;
  for(int i = 0;i<b;i++)
    {
     for(int j = 0;j<b-1;j++)
     {
      if(a[j] > a[j+1])
      {
	temp = a[j];
	a[j] = a[j+1];
	a[j+1] = temp;
      }
    }
  }
}
void display(int a[],int b)
{
  for(int i = 0;i<b;i++)
    cout << a[i] << " ";
  cout << endl;
}
int main()
 {
  int t;
  int a[t];
  while(cin >> t)
    {
    if( t == 0)
      break;
    for(int i = 0;i< t;i++)
      cin >> a[i];
    BubbleSort(a,t);
    display(a,t);
  }
}

