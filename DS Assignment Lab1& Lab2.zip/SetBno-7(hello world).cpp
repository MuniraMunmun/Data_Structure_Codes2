#include <iostream>
using namespace std;
  int Recurtion(int a)
  {
    if(a==0)
     return 0;
     cout<<"\n Hello World!" << endl;

    Recurtion(a-1);
  }
 int main()
 {
    Recurtion(1);
 }

