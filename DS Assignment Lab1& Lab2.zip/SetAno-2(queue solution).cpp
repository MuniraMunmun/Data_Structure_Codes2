#include <iostream>
#define Limit 5
using namespace std;
 int que[Limit];
 int Data=0;
 int Start =-1;
 int Next =-1;

bool Overflow()
{
    if (Data == Limit)
        return true;
    else
        return false;
}
bool Underflow()
{
    if (Data == 0)
        return true;
    else
        return false;
}
int Enqueue(int a)
  {
    if(Overflow())
        cout<<" Overflow "<<endl;
        else
           {
            if(Start<0)
                Start++;
                Next++;
              que[Next] = a;
              Data++;
           }
           return 0;
  }

int Dequeue()
 {
     if(Underflow())
        cout<<"Underflow"<<endl;
     else
        {
            cout<< que[Start] <<endl;
              if(Start<Next && Start!= Limit)
                Start++;
              Data--;
        }
        return 0;
 }

 void Display(int x)
  {
      if(Start> x)
        cout<< " NULL "<<endl;
    else
        cout<<que[x]<<endl;
  }

int main()
{
    Dequeue();
     Enqueue(1);
     Enqueue(2);
     Enqueue(3);
      Enqueue(4);
      Enqueue(5);
      Enqueue(6);
      Enqueue(7);
    Dequeue();
    Dequeue();
    Dequeue();
    Dequeue();
     Dequeue();
     Dequeue();
     Dequeue();
     Dequeue();

     Display(5);
}




