#include <iostream>
using namespace std;
  int BubbleSort(int a[],int b)
  {
    int temp;
    int count;
     for(int i = 0;i<b;i++)
      {
        for(int j = 0;j<b-1;j++)
        {
         if(a[j] > a[j+1])
         {
	      temp= a[j];
	      a[j]= a[j+1];
	      a[j+1]= temp;
        	count++;
         }
        }
      }
      return count;
   }
int main()
{
  int n;
  int array[n];
  while(cin>> n)
    {
     for(int i = 0;i<n;i++)
      cin>> array[i];
    int a= BubbleSort(array,n);
    cout<<"Minimum exchange operations : "<<a <<endl;
    }
}

