#include <iostream>
using namespace std;

int main()
{
    int a1= 0, a2= 1,sum = 0,n;

    cout << "Enter the number: \n";
    cin >> n;

    cout << "Fibonacci Series is: \n";
       for (int i = 1; i <= n; ++i)
        {
          if(i== 1)
           {
             cout << "  " << a1;
             continue;
           }
          if(i == 2)
           {
             cout << a2 << " ";
             continue;
           }
           sum=a1 +a2;
           a1 = a2;
           a2 = sum;
        cout<< sum << " ";
      }
       return 0;
}
