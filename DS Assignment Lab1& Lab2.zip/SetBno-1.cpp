#include <iostream>
using namespace std;
  int BubbleSort(int a[],int b)
   {
     int temp;
     int count=0;
    for(int i=0; i<b; i++)
     {
       for(int j=0; j<b-1; j++)
        {
          if(a[j]> a[j+1])
          {
	        temp= a[j];
	        a[j]= a[j+1];
            a[j+1]= temp;
	         count++;
          }
        }
     }
      return count;
  }
  int main()
  {
    int T,L,train[50];
     cin>> T;
     while(T--)
      {
        cin >> L;
       for(int i=0; i<L; i++)
        cin>> train[i];
       int a = BubbleSort(train,L);
         cout<< "Optimal train swapping takes " <<a <<" swaps."<<endl;
      }
   }

