#include<iostream>
using namespace std;

int main()
{
    int ar1[4]={1, 12,32,11};
    int ar2[4]={3, 10, 15, 14};
    int ar3[4],i,n;

     int x=3, y=0;
     for(int i=0;i<4;i++)
     {
       ar3[y]= ar1[i]+ar2[x];

       cout<<ar3[y]<<" ";
     x--;
     y++;
     }
     cout<<endl;
     return 0;

}
