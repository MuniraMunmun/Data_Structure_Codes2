#include <iostream>
using namespace std;
int main()
{
    int a=0,b,n,i;
    cout<<"Enter a positive integer: ";
    while(cin>>n)
    {
         if(n == 0)
            break;
      for(i=2;i<=n/2;i++)
       {
        if(n%i==0)
        {
            a=1;
            break;
        }
       }
     if(a==0)
        cout<<"\nPrime number!"<<endl;
     else
        cout<<"\nNot Prime.."<<endl;
    }
}
